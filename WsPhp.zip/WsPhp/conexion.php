<?php

class JConfig {

   public $dbtype = 'mysqli';

   public $host = 'localhost';

   public $user = 'root';

   public $password = '';

   public $db = 'u770133628_curso_android';

}

?>