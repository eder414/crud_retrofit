<?php
require_once "conexion.php";
$Conf = new JConfig;

	/* Conectar a una base de datos de MySQL invocando al controlador */
	/*$dsn = 'mysql:dbname=vote;host=127.0.0.1;charset=utf8';*/


if($_REQUEST['action'] == 'uploadFile'){
	$dsn = 'mysql:dbname='.$Conf->db.';host='.$Conf->host.';charset=utf8';
	$usuario =  $Conf->user;
	$contraseña = $Conf->password;



    $imagen=UploadFiles($_FILES,'Imagenes');

	echo('[{"response":"OK"}]');

    
}
if($_REQUEST['action'] == 'insertUsuario'){
	$dsn = 'mysql:dbname='.$Conf->db.';host='.$Conf->host.';charset=utf8';
	$usuario =  $Conf->user;
	$contraseña = $Conf->password;


    $usuario_nombre = $_REQUEST['usuario_nombre'];
    $usuario_password = $_REQUEST['usuario_password'];
	$usuario_sexo = $_REQUEST['usuario_sexo'];
	$usuario_edad = $_REQUEST['usuario_edad'];


    /*
        @Part List<MultipartBody.Part> Files,
        @Part("nombre") RequestBody nombre,
        @Part("direccion") RequestBody direccion);

        $datos = json_decode($_REQUEST['datos']);
    */

	try {
	    $gbd = new PDO($dsn, $usuario, $contraseña);
	} catch (PDOException $e) {
	    echo 'Falló la conexión: ' . $e->getMessage();
	}
	/* Ejecutar una sentencia preparada vinculando varialbes de PHP */

	$sql = 'CALL u770133628_curso_android.P_InsertarUsuario(?,?,?,?,@response)';
	$stmt = $gbd->prepare($sql);
	$stmt->bindParam(1, $usuario_nombre, PDO::PARAM_STR,100);
	$stmt->bindParam(2, $usuario_sexo, PDO::PARAM_INT);
	$stmt->bindParam(3, $usuario_edad, PDO::PARAM_INT);
	$stmt->bindParam(4, $usuario_password, PDO::PARAM_STR,1000);

	$stmt->execute();

	//GetResponses
	$sql = "SELECT @response as response";
	$stmt = $gbd->prepare($sql);
	$stmt->execute();
	$resultado = $stmt->fetchAll();
	$p_Responses = array();
    $z = 0;
	foreach ($resultado as $row) {
        $p_Responses[$z]['response'] = $row[0];
        $z++;
	}
	
	$resultado = $stmt->fetchAll();

	$stmt = null;
	$gbd = null;
	$dsn = null;
	echo(json_encode($p_Responses));

    
}
if($_REQUEST['action'] == 'P_Actualizar'){
	$dsn = 'mysql:dbname='.$Conf->db.';host='.$Conf->host.';charset=utf8';
	$usuario =  $Conf->user;
	$contraseña = $Conf->password;


    $usuario_nombre = $_REQUEST['usuario_nombre'];
    $usuario_password = $_REQUEST['usuario_password'];
	$usuario_sexo = $_REQUEST['usuario_sexo'];
	$usuario_edad = $_REQUEST['usuario_edad'];
	$id = $_REQUEST['id'];


    /*
        @Part List<MultipartBody.Part> Files,
        @Part("nombre") RequestBody nombre,
        @Part("direccion") RequestBody direccion);

        $datos = json_decode($_REQUEST['datos']);
    */

	try {
	    $gbd = new PDO($dsn, $usuario, $contraseña);
	} catch (PDOException $e) {
	    echo 'Falló la conexión: ' . $e->getMessage();
	}
	/* Ejecutar una sentencia preparada vinculando varialbes de PHP */

	/*P_Actualizar`(id int,
									nombre varchar(45),
																sexo int,
                                                                edad int,
                                                                _password varchar(45),
                                                                out response varchar(45)*/

	$sql = 'CALL u770133628_curso_android.P_Actualizar(?,?,?,?,?,@response)';
	$stmt = $gbd->prepare($sql);
	$stmt->bindParam(1, $id, PDO::PARAM_INT);
	$stmt->bindParam(2, $usuario_nombre, PDO::PARAM_STR,100);
	$stmt->bindParam(3, $usuario_sexo, PDO::PARAM_INT);
	$stmt->bindParam(4, $usuario_edad, PDO::PARAM_INT);
	$stmt->bindParam(5, $usuario_password, PDO::PARAM_STR,1000);

	$stmt->execute();

	//GetResponses
	$sql = "SELECT @response as response";
	$stmt = $gbd->prepare($sql);
	$stmt->execute();
	$resultado = $stmt->fetchAll();
	$p_Responses = array();
    $z = 0;
	foreach ($resultado as $row) {
        $p_Responses[$z]['response'] = $row[0];
        $z++;
	}
	
	$resultado = $stmt->fetchAll();

	$stmt = null;
	$gbd = null;
	$dsn = null;
	echo(json_encode($p_Responses));

    
}
if($_REQUEST['action'] == 'P_ObtenerUsuario'){
	$dsn = 'mysql:dbname='.$Conf->db.';host='.$Conf->host.';charset=utf8';
	$usuario =  $Conf->user;
	$contraseña = $Conf->password;



    /*
        @Part List<MultipartBody.Part> Files,
        @Part("nombre") RequestBody nombre,
        @Part("direccion") RequestBody direccion);

        $datos = json_decode($_REQUEST['datos']);
    */

	try {
	    $gbd = new PDO($dsn, $usuario, $contraseña);
	} catch (PDOException $e) {
	    echo 'Falló la conexión: ' . $e->getMessage();
	}
	/* Ejecutar una sentencia preparada vinculando varialbes de PHP */

	/*P_Actualizar`(id int,
									nombre varchar(45),
																sexo int,
                                                                edad int,
                                                                _password varchar(45),
                                                                out response varchar(45)*/

	$sql = 'CALL u770133628_curso_android.P_ObtenerUsuario()';
	$stmt = $gbd->prepare($sql);

	$stmt->execute();

	$resultado = $stmt->fetchAll();
	/*`usuarios`.`usuario_id`,
    `usuarios`.`usuario_nombre`,
    `usuarios`.`usuario_sexo`,
    `usuarios`.`usuario_edad`,
    `usuarios`.`usuario_password`*/
	$z = 0;
	$vector = array();
	foreach ($resultado as $row) {
		$vector[$z]['usuario_id']=$row[0];
		$vector[$z]['usuario_nombre']=$row[1];
		$vector[$z]['usuario_sexo']=$row[2];
		$vector[$z]['usuario_edad']=$row[3];
		$vector[$z]['usuario_password']=$row[4];
	    $z++;
	}
	
	$stmt = null;
	$gbd = null;
	$dsn = null;
	echo(json_encode($vector));

    
}
if($_REQUEST['action'] == 'P_DeleteUsuario'){
	$dsn = 'mysql:dbname='.$Conf->db.';host='.$Conf->host.';charset=utf8';
	$usuario =  $Conf->user;
	$contraseña = $Conf->password;

	$id = $_REQUEST['id'];


    /*
        @Part List<MultipartBody.Part> Files,
        @Part("nombre") RequestBody nombre,
        @Part("direccion") RequestBody direccion);

        $datos = json_decode($_REQUEST['datos']);
    */

	try {
	    $gbd = new PDO($dsn, $usuario, $contraseña);
	} catch (PDOException $e) {
	    echo 'Falló la conexión: ' . $e->getMessage();
	}
	/* Ejecutar una sentencia preparada vinculando varialbes de PHP */

	/*P_Actualizar`(id int,
									nombre varchar(45),
																sexo int,
                                                                edad int,
                                                                _password varchar(45),
                                                                out response varchar(45)*/

	$sql = 'CALL u770133628_curso_android.P_DeleteUsuario(?,@response)';
	$stmt = $gbd->prepare($sql);
	$stmt->bindParam(1, $id, PDO::PARAM_INT);

	$stmt->execute();

	//GetResponses
	$sql = "SELECT @response as response";
	$stmt = $gbd->prepare($sql);
	$stmt->execute();
	$resultado = $stmt->fetchAll();
	$p_Responses = array();
    $z = 0;
	foreach ($resultado as $row) {
        $p_Responses[$z]['response'] = $row[0];
        $z++;
	}
	
	$resultado = $stmt->fetchAll();

	$stmt = null;
	$gbd = null;
	$dsn = null;
	echo(json_encode($p_Responses));

    
}

if($_REQUEST['action'] == 'getTiendas'){
	$dsn = 'mysql:dbname='.$Conf->db.';host='.$Conf->host.';charset=utf8';
	$usuario =  $Conf->user;
	$contraseña = $Conf->password;

	try {
	    $gbd = new PDO($dsn, $usuario, $contraseña);
	} catch (PDOException $e) {
	    echo 'Falló la conexión: ' . $e->getMessage();
	}
	/* Ejecutar una sentencia preparada vinculando varialbes de PHP */

	$sql = 'CALL curso_android.P_GetTiendas()';
	$stmt = $gbd->prepare($sql);


	$stmt->execute();

	//GetResponses
	$sql = "SELECT @response as response";
	$stmt = $gbd->prepare($sql);
	$stmt->execute();
	$resultado = $stmt->fetchAll();
	$p_Responses = array();
    $z = 0;
	foreach ($resultado as $row) {
        $p_Responses[$z]['id'] = $row[0];
		$p_Responses[$z]['nombre'] = $row[1];
		$p_Responses[$z]['direccion'] = $row[2];
		$p_Responses[$z]['imagen'] = $row[3];
        $z++;
	}
	
	$resultado = $stmt->fetchAll();

	$stmt = null;
	$gbd = null;
	$dsn = null;
	echo(json_encode($p_Responses));

    
}
if($_REQUEST['action'] == 'deleteTienda'){
	$dsn = 'mysql:dbname='.$Conf->db.';host='.$Conf->host.';charset=utf8';
	$usuario =  $Conf->user;
	$contraseña = $Conf->password;



    $nombre = $_REQUEST['nombre'];
    $direccion = $_REQUEST['direccion'];


    /*
        @Part List<MultipartBody.Part> Files,
        @Part("nombre") RequestBody nombre,
        @Part("direccion") RequestBody direccion);

        $datos = json_decode($_REQUEST['datos']);
    */

	try {
	    $gbd = new PDO($dsn, $usuario, $contraseña);
	} catch (PDOException $e) {
	    echo 'Falló la conexión: ' . $e->getMessage();
	}
	/* Ejecutar una sentencia preparada vinculando varialbes de PHP */

	$sql = 'CALL curso_android.P_InsertTienda(?,?,?,@response)';
	$stmt = $gbd->prepare($sql);
	$stmt->bindParam(1, $nombre, PDO::PARAM_STR,100);
	$stmt->bindParam(2, $direccion, PDO::PARAM_STR,1000);
	$stmt->bindParam(3, $imagen, PDO::PARAM_STR,1000);

	$stmt->execute();

	//GetResponses
	$sql = "SELECT @response as response";
	$stmt = $gbd->prepare($sql);
	$stmt->execute();
	$resultado = $stmt->fetchAll();
	$p_Responses = array();
    $z = 0;
	foreach ($resultado as $row) {
        $p_Responses[$z]['response'] = $row[0]." direccion: ".$direccion;
        $z++;
	}
	
	$resultado = $stmt->fetchAll();

	$stmt = null;
	$gbd = null;
	$dsn = null;
	echo(json_encode($p_Responses));

    
}

function UploadFiles($files,$folder){

    $response = "";

    $dir_subida = './'.$folder.'/';
    $fichero_subido = $dir_subida . basename($files['files']['name']);

    if (move_uploaded_file($files['files']['tmp_name'], $fichero_subido)) {
        $response = $fichero_subido;
    } else {
        $response = "";
    }
    return $response;
}

?>
